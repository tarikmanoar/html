
/*
Template Name: Adminto - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
File: Form Validation init js
*/

$(document).ready(function() {
    $('form').parsley();
});
