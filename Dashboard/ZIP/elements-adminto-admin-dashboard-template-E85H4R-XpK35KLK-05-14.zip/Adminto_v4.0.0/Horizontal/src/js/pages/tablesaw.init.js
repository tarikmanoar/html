
/*
Template Name: Adminto - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
File: Tablesaw init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
