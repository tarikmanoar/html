/*

Project     : DAdmin - Responsive Bootstrap HTML Admin Dashboard
Version     : 1.1
Author      : ThemeLooks
Author URI  : https://themeforest.net/user/themelooks

*/

Dropzone.options.dropzone01 = {
    addRemoveLinks: true,
    dictRemoveFile: ''
};
